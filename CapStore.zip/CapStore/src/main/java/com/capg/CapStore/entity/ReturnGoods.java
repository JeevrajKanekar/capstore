package com.capg.CapStore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="return_goods_tbl")
public class ReturnGoods {
	public ReturnGoods() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ReturnGoods(int returnOrderId, @NotNull @Size(max = 30) String returnStatus,
			@NotNull @Size(max = 100) String reasonToReturn, @NotNull @Size(max = 255) String reasonDescription,
			@Size(max = 6) Customer customer, @Size(max = 6) Order order, @Size(max = 6) Product product) {
		super();
		this.returnOrderId = returnOrderId;
		this.returnStatus = returnStatus;
		this.reasonToReturn = reasonToReturn;
		this.reasonDescription = reasonDescription;
		this.customer = customer;
		this.order = order;
		this.product = product;
	}
	@Override
	public String toString() {
		return "ReturnGoods [returnOrderId=" + returnOrderId + ", returnStatus=" + returnStatus + ", reasonToReturn="
				+ reasonToReturn + ", reasonDescription=" + reasonDescription + ", customer=" + customer + ", order="
				+ order + ", product=" + product + "]";
	}
	public int getReturnOrderId() {
		return returnOrderId;
	}
	public void setReturnOrderId(int returnOrderId) {
		this.returnOrderId = returnOrderId;
	}
	public String getReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(String returnStatus) {
		this.returnStatus = returnStatus;
	}
	public String getReasonToReturn() {
		return reasonToReturn;
	}
	public void setReasonToReturn(String reasonToReturn) {
		this.reasonToReturn = reasonToReturn;
	}
	public String getReasonDescription() {
		return reasonDescription;
	}
	public void setReasonDescription(String reasonDescription) {
		this.reasonDescription = reasonDescription;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int returnOrderId;
	@NotNull
	@Size(max=30)
	@Column(length=30)
	private String returnStatus;
	@NotNull
	@Size(max=100)
	@Column(length=100)
	private String reasonToReturn;
	@NotNull
	@Size(max=255)
	@Column(length=255)
	private String reasonDescription;
	@OneToOne
	//@Size(max=6)
	//@Column(length=6)
	private Customer customer;//foreign key references Customer,
	@OneToOne
	//@Size(max=6)
	//@Column(length=6)
	private Order order;//foreign key references Order
	@OneToOne
	//@Size(max=6)
	//@Column(length=6)
	private Product product; // returned one 

}
