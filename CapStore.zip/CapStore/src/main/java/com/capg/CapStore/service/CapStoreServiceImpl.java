package com.capg.CapStore.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.CapStore.repository.ICapStoreRepository;

@Service
@Transactional
public class CapStoreServiceImpl implements ICapStoreService{

	@Autowired
	ICapStoreRepository repository;

	@Override
	public void addData() 
	{
		repository.addData();
	}
	
}

