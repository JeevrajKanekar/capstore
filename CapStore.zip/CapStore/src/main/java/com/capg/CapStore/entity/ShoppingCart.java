package com.capg.CapStore.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name="shopping_cart_tbl")
public class ShoppingCart {
	
	public ShoppingCart() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ShoppingCart(int cartId, @Size(max = 6) Customer customer, List<ShoppingCartItem> items) {
		super();
		this.cartId = cartId;
		this.customer = customer;
		this.items = items;
	}
	@Override
	public String toString() {
		return "ShoppingCart [cartId=" + cartId + ", customer=" + customer + ", items=" + items + "]";
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public List<ShoppingCartItem> getItems() {
		return items;
	}
	public void setItems(List<ShoppingCartItem> items) {
		this.items = items;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int cartId;
	@OneToOne
	//@Size(max=6)
	//@Column(length=6)
	private Customer customer;//foreign key references customer
	@OneToMany(mappedBy="cart",cascade=CascadeType.ALL)
	//@Column(length=10)
	private List<ShoppingCartItem> items=new ArrayList<>();
}
