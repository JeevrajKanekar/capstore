package com.capg.CapStore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
@Entity
@Table(name="Revenue_tbl")
public class Revenue {
	public Revenue() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Revenue(int revenueId, @NotNull @Size(max = 2) int month, @NotNull @Size(max = 4, min = 4) int year,
			@NotNull @Size(max = 10) double revenueAmount) {
		super();
		this.revenueId = revenueId;
		this.month = month;
		this.year = year;
		this.revenueAmount = revenueAmount;
	}
	@Override
	public String toString() {
		return "Revenue [revenueId=" + revenueId + ", month=" + month + ", year=" + year + ", revenueAmount="
				+ revenueAmount + "]";
	}
	public int getRevenueId() {
		return revenueId;
	}
	public void setRevenueId(int revenueId) {
		this.revenueId = revenueId;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public double getRevenueAmount() {
		return revenueAmount;
	}
	public void setRevenueAmount(double revenueAmount) {
		this.revenueAmount = revenueAmount;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int revenueId;
	@NotNull
	//@Size(max=2)
	@Column(length=2)
	private int month;
	@NotNull
	//@Size(max=4,min=4)
	@Column(length=4)
	private int year;
	@NotNull
	//@Size(max=10)
	@Column(length=10)
	private double revenueAmount;

}
