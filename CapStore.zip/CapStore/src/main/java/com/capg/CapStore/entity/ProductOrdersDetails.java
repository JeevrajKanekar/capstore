package com.capg.CapStore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;


@Entity
@Table(name="product_orders_details_tbl")
public class ProductOrdersDetails {
	public ProductOrdersDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ProductOrdersDetails(int productOrderId, Product product, Order order, int quantity, double subAmount,
			String productSize) {
		super();
		this.productOrderId = productOrderId;
		this.product = product;
		this.order = order;
		this.quantity = quantity;
		this.subAmount = subAmount;
		this.productSize = productSize;
	}

	public int getProductOrderId() {
		return productOrderId;
	}
	public void setProductOrderId(int productOrderId) {
		this.productOrderId = productOrderId;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getSubAmount() {
		return subAmount;
	}
	public void setSubAmount(double subAmount) {
		this.subAmount = subAmount;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	//@SequenceGenerator(sequenceName="")
    private int productOrderId;
	//@Size(max=6)
	//@Column(length=6)
	@OneToOne
	private Product product; 
	//@Size(max=6)
	//@Column(length=6)
	@OneToOne
	private Order order;
	//@Size(max=10)
	@Column(length=10)
	private int quantity;
	//@Size(max=10)
	@Column(length=10)
	private double subAmount;
	@Column
	private String productSize;
	public String getProductSize() {
		return productSize;
	}
	public void setProductSize(String size) {
		this.productSize = size;
	}
	
}
