package com.capg.CapStore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
@Entity
@Table(name="Feedback_tbl")
public class Feedback {
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Feedback(int feedbackId, @NotNull @Size(max = 255) String comment, @NotNull @Max(5) @Min(0) int rating,
			@NotNull Product product, @NotNull Customer customer) {
		super();
		this.feedbackId = feedbackId;
		this.comments = comment;
		this.rating = rating;
		this.product = product;
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Feedback [feedbackId=" + feedbackId + ", comment=" + comments + ", rating=" + rating + ", product="
				+ product + ", customer=" + customer + "]";
	}
	public int getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int feedbackId;
	@NotNull
	@Size(max=255)
	@Column(length=255)
	private String comments;
	@NotNull
	@Max(5)
	@Min(0)
	@Column(length=5)
	private int rating;
	@OneToOne
	@NotNull
	//@Column(length=10)
	private Product product;//foreign key references Product,
	@OneToOne
	@NotNull
	//@Column(length=10)
	private Customer customer;//foreign key references Customer

}
