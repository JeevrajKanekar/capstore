package com.capg.CapStore.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name="Coupons_tbl")
public class Coupons {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int couponCode;
	@Column(length=30)
	private String startDate;
	@Column(length=30)
	private String expiryDate;
	@Size(max=255)
	@Column(length=255)
	private String description; //terms and condition to show to user
	@Column(length=30)
	private int discountPercent;
	@Column(length=10)
	private int minAmount;
	@OneToOne
	private Category category;//foreign key of category
	public Coupons() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Coupons(int couponCode, @Size(max = 30) String startDate, @Size(max = 30) String expiryDate,
			@Size(max = 255) String description, @Size(max = 30) int discountPercent, @Size(max = 10) int minAmount,
			@Size(max = 6) Category category) {
		super();
		this.couponCode = couponCode;
		this.startDate = startDate;
		this.expiryDate = expiryDate;
		this.description = description;
		this.discountPercent = discountPercent;
		this.minAmount = minAmount;
		this.category = category;
	}
	@Override
	public String toString() {
		return "Coupons [couponCode=" + couponCode + ", startDate=" + startDate + ", expiryDate=" + expiryDate
				+ ", description=" + description + ", discountPercent=" + discountPercent + ", minAmount=" + minAmount
				+ ", category=" + category + "]";
	}
	public int getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(int couponCode) {
		this.couponCode = couponCode;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getDiscountPercent() {
		return discountPercent;
	}
	public void setDiscountPercent(int discountPercent) {
		this.discountPercent = discountPercent;
	}
	public int getMinAmount() {
		return minAmount;
	}
	public void setMinAmount(int minAmount) {
		this.minAmount = minAmount;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}

}
