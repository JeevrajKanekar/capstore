package com.capg.CapStore.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name="Merchant_tbl",uniqueConstraints= {@UniqueConstraint(columnNames= {"merchantEmailId","mobileNo"})})
public class Merchant {
	public Merchant() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Merchant(int merchantId, @Size(max = 10) int gstIn,
			@NotNull @Size(max = 30) String merchantName,
			@NotNull @Size(max = 50) String merchantEmailId,
			@NotNull @Size(max = 10, min = 10) String mobileNo,
			List<Product> products, @NotNull @Size(max = 20) String merchantType, Address address,
			@Size(max = 5, min = 0) double averageRating) {
		super();
		this.merchantId = merchantId;
		this.gstIn = gstIn;
		this.merchantName = merchantName;
		this.merchantEmailId = merchantEmailId;
		this.mobileNo = mobileNo;
		this.products = products;
		this.merchantType = merchantType;
		this.address = address;
		this.averageRating = averageRating;
	}
	@Override
	public String toString() {
		return "Merchant [merchantId=" + merchantId + ", gstIn=" + gstIn + ", merchantName=" + merchantName
				+ ", merchantEmailId=" + merchantEmailId + ", mobileNo=" + mobileNo + ", products=" + products
				+ ", merchantType=" + merchantType + ", address=" + address + ", averageRating=" + averageRating + "]";
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public int getGstIn() {
		return gstIn;
	}
	public void setGstIn(int gstIn) {
		this.gstIn = gstIn;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getMerchantEmailId() {
		return merchantEmailId;
	}
	public void setMerchantEmailId(String merchantEmailId) {
		this.merchantEmailId = merchantEmailId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	public String getMerchantType() {
		return merchantType;
	}
	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public double getAverageRating() {
		return averageRating;
	}
	public void setAverageRating(double averageRating) {
		this.averageRating = averageRating;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int merchantId;
	//@Size(max=10)
	@Column(length=10)
	private int gstIn;
	@NotNull
	@Size(max=30)
	@Column(length=30)
	//@Pattern(regexp="[A-Za-z\\s+]")
	private String merchantName;
	@NotNull
	@Size(max=50)
	@Column(length=50)
	//@Pattern(regexp="^(.+)@(.+)$")
	private String merchantEmailId;
	@NotNull
	@Size(max=10,min=10)
	@Column(length=10)
	//@Pattern(regexp="[7-9][0-9]{9}")
	private String mobileNo;
	@OneToMany(mappedBy="productId")
	@Column(length=6)
	private List<Product> products=new ArrayList<>(); //references product,        //list //Many to Many
	@NotNull
	@Size(max=20)
	@Column(length=20)
	private String merchantType;
	@OneToOne
	private Address address;
	//@Size(max=5,min=0)
	@Column(length=5)
	private double averageRating;

}
