package com.capg.CapStore.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;
@Entity
@Table(name="shopping_cart_item_tbl")
public class ShoppingCartItem {
	public ShoppingCartItem() {
		
	}
	
	public ShoppingCartItem(int cartItemId, Product product, ShoppingCart cart, int productQuantity,
			@Size(max = 30) String addedDateTime, String productSize) {
		super();
		this.cartItemId = cartItemId;
		this.product = product;
		this.cart = cart;
		this.productQuantity = productQuantity;
		this.addedDateTime = addedDateTime;
		this.productSize = productSize;
	}

	public int getCartItemId() {
		return cartItemId;
	}
	public void setCartItemId(int cartItemId) {
		this.cartItemId = cartItemId;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public String getAddedDateTime() {
		return addedDateTime;
	}
	public void setAddedDateTime(String addedDateTime) {
		this.addedDateTime = addedDateTime;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int cartItemId;
	//@Column(length=6)
	//@Size(max=6)
	@OneToOne
	private Product product;//foreign key references Product,
	@ManyToOne(cascade=CascadeType.PERSIST)
	private ShoppingCart cart;//foreign key references Shopping_cart,
	//@Size(max=10)
	@Column(length=10)
	private int productQuantity;//not null,
	@Size(max=30)
	@Column(length=30)
	private String addedDateTime;
	@Column
	private String productSize;
	public ShoppingCart getCart() {
		return cart;
	}
	public void setCart(ShoppingCart cart) {
		this.cart = cart;
	}
	public String getSize() {
		return productSize;
	}
	public void setSize(String productSize) {
		this.productSize = productSize;
	}
	
}
