package com.capg.CapStore.repository;

public interface ICapStoreRepository {
	public void addData();
}
