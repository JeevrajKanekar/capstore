package com.capg.CapStore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name="shipping_table_tbl")
public class ShippingTable {
	public ShippingTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ShippingTable(int shippingId, Order order, Invoice invoiceId,
			@NotNull @Size(max = 30) String receiverName,
			@NotNull Address address) {
		super();
		this.shippingId = shippingId;
		this.order = order;
		this.invoiceId = invoiceId;
		this.receiverName = receiverName;
		this.address = address;
	}

	@Override
	public String toString() {
		return "ShippingTable [order=" + order + ", invoiceId=" + invoiceId + ", receiverFirstname=" + receiverName
				 + ", address=" + address + "]";
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public Invoice getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(Invoice invoiceId) {
		this.invoiceId = invoiceId;
	}
	public String getReceiverFirstname() {
		return receiverName;
	}
	public void setReceiverFirstname(String receiverName) {
		this.receiverName = receiverName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int shippingId;
	public int getShippingId() {
		return shippingId;
	}
	public void setShippingId(int shippingId) {
		this.shippingId = shippingId;
	}
	@OneToOne
	//@Size(max=6)
	//@Column(length=6)
	private Order order;//foreign key references Order,
	@OneToOne
	//@Size(max=6)
	//@Column(length=6)
	private Invoice invoiceId;// foreign key references Invoice,
	@NotNull
	@Size(max=30)
	@Column(length=30)
	//@Pattern(regexp="[A-Za-z\\s+]")
	private String receiverName;
	@NotNull
	//@Size(max=6)
	//@Column(length=6)
	@OneToOne
	private Address address;

}
