package com.capg.CapStore.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="Product_tbl")
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productId;
	@NotNull
	@Size(max=50)
	@Column(length=50)
	private String productName;
	@ManyToOne(fetch=FetchType.LAZY)
	@MapsId("categoryId")
	@JoinColumn(name="categoryId",referencedColumnName="categoryId",updatable=true,nullable=false)
	private Category category; //foreign key of category,
	@NotNull
	@Size(max=255)
	@Column(length=255)
	private String description;
	@NotNull
	@Column(length=10)
	private double price;
	@NotNull
	@Size(max=20)
	@Column(length=20)	
	private String keywordtoSearch;
	@NotNull
	@Size(max=255)
	@Column(length=255)
	private String imageUrl; 
	@Column(length=5)	
	private double averageRatings;
	public Product() {}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getKeywordtoSearch() {
		return keywordtoSearch;
	}
	public void setKeywordtoSearch(String keywordtoSearch) {
		this.keywordtoSearch = keywordtoSearch;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public double getAverageRatings() {
		return averageRatings;
	}
	public void setAverageRatings(double averageRatings) {
		this.averageRatings = averageRatings;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", category=" + category
				+ ", description=" + description + ", price=" + price + ", keywordtoSearch=" + keywordtoSearch
				+ ", imageUrl=" + imageUrl + ", averageRatings=" + averageRatings + "]";
	}
	public Product(int productId, @NotNull @Size(max = 50) String productName, Category category,
			@NotNull @Size(max = 255) String description, @NotNull double price,
			@NotNull @Size(max = 20) String keywordtoSearch, @NotNull @Size(max = 255) String imageUrl,
			double averageRatings) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.category = category;
		this.description = description;
		this.price = price;
		this.keywordtoSearch = keywordtoSearch;
		this.imageUrl = imageUrl;
		this.averageRatings = averageRatings;
	}
	
}

