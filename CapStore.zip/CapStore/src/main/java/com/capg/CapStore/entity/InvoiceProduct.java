package com.capg.CapStore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="invoice_product_tbl")
public class InvoiceProduct {
	
	public InvoiceProduct() {
		super();
		// TODO Auto-generated constructor stub
	}
	public InvoiceProduct(int invoiceProductId, @NotNull Invoice invoice, @NotNull Product product, int cgst,
			int sgst, int igst) {
		super();
		this.invoiceProductId = invoiceProductId;
		this.invoice = invoice;
		this.product = product;
		this.cgst = cgst;
		this.sgst = sgst;
		this.igst = igst;
	}
	public int getInvoiceProductId() {
		return invoiceProductId;
	}
	public void setInvoiceProductId(int invoiceProductId) {
		this.invoiceProductId = invoiceProductId;
	}
	public Invoice getInvoice() {
		return invoice;
	}
	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}
	@Override
	public String toString() {
		return "InvoiceProduct [invoiceId=" + invoice + ", product=" + product + ", cgst=" + cgst + ", sgst=" + sgst
				+ ", igst=" + igst + "]";
	}
	public Invoice getInvoiceId() {
		return invoice;
	}
	public void setInvoiceId(Invoice invoice) {
		this.invoice = invoice;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public int getCgst() {
		return cgst;
	}
	public void setCgst(int cgst) {
		this.cgst = cgst;
	}
	public int getSgst() {
		return sgst;
	}
	public void setSgst(int sgst) {
		this.sgst = sgst;
	}
	public int getIgst() {
		return igst;
	}
	public void setIgst(int igst) {
		this.igst = igst;
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int invoiceProductId;
	@OneToOne
	//@NotNull
	//@Column(length=6)
	private Invoice invoice;//foreign key references Invoice,
	@OneToOne
	//@NotNull
	//@Column(length=6)
	//@Size(max=6)
	private Product product;// foreign key references Product,
	//@Size(max=10)
	@Column(length=10)
	private int cgst;
	//@Size(max=10)
	@Column(length=10)
	private int sgst;
	//@Size(max=10)
	@Column(length=10)
	private int igst;

	
}
