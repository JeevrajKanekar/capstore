package com.capg.CapStore.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="Order_tbl")
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int orderId;
	@ManyToOne(cascade=CascadeType.PERSIST)
	@NotNull
	private Customer customer;// references customer_master(customer_id), //onetoone
	@NotNull
	@Size(max=255)
	@Column(length=255)
	private String address;
	@NotNull
	@Column(length=30)
	private String expectedDate;
	@NotNull
	@Column(length=30)
	private String delieveryDate; 
	@NotNull
	@Column(length=10)
	private double totalPrice; // with gst
	@NotNull
	@Size(max=20)
	@Column(length=20)
	private String status;
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Order(int orderId, @NotNull Customer customer, @NotNull @Size(max = 255) String address,
			@NotNull @Size(max = 30) String expectedDate, @NotNull @Size(max = 30) String delieveryDate,
			@NotNull @Size(max = 10) double totalPrice, @NotNull @Size(max = 20) String status) {
		super();
		this.orderId = orderId;
		this.customer = customer;
		this.address = address;
		this.expectedDate = expectedDate;
		this.delieveryDate = delieveryDate;
		this.totalPrice = totalPrice;
		this.status = status;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", customer=" + customer + ", address=" + address + ", expectedDate="
				+ expectedDate + ", delieveryDate=" + delieveryDate + ", totalPrice=" + totalPrice + ", status="
				+ status + "]";
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getExpectedDate() {
		return expectedDate;
	}
	public void setExpectedDate(String expectedDate) {
		this.expectedDate = expectedDate;
	}
	public String getDelieveryDate() {
		return delieveryDate;
	}
	public void setDelieveryDate(String delieveryDate) {
		this.delieveryDate = delieveryDate;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}


}
