package com.capg.CapStore.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


@Entity
@Table(name="Customer_tbl",uniqueConstraints= {@UniqueConstraint(columnNames= {"customerEmailId","customerMobileno"})})
public class Customer {
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(int customerId, @NotNull @Size(max = 30) String customerName,
			@NotNull @Size(max = 10, min = 10) String customerMobileno,
			@NotNull @Size(max = 50) String customerEmailId,
			@NotNull List<Address> customerAddresses, @NotNull List<Order> orders) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerMobileno = customerMobileno;
		this.customerEmailId = customerEmailId;
		this.customerAddresses = customerAddresses;
		this.orders = orders;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerMobileno="
				+ customerMobileno + ", customerEmailId=" + customerEmailId + ", customerAddresses=" + customerAddresses
				+ ", orders=" + orders + "]";
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerMobileno() {
		return customerMobileno;
	}
	public void setCustomerMobileno(String customerMobileno) {
		this.customerMobileno = customerMobileno;
	}
	public String getCustomerEmailId() {
		return customerEmailId;
	}
	public void setCustomerEmailId(String customerEmailId) {
		this.customerEmailId = customerEmailId;
	}
	public List<Address> getCustomerAddresses() {
		return customerAddresses;
	}
	public void setCustomerAddresses(List<Address> customerAddresses) {
		this.customerAddresses = customerAddresses;
	}
	public List<Order> getOrders() {
		return orders;
	}
	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customerId;
	@NotNull
	@Size(max=30)
	@Column(length=30)
	//@Pattern(regexp="[A-Za-z\\s+]")
	private String customerName;
	@NotNull
	@Size(max=10,min=10)
	@Column(length=10)
	//@Pattern(regexp="[7-9][0-9]{9}")
	private String customerMobileno;
	@NotNull
	@Size(max=50)
	@Column(length=50)
	//@Pattern(regexp="^(.+)@(.+)$")
	private String customerEmailId; //unique
	@NotNull
	@OneToMany(mappedBy="customer")
	//@Column(length=10)
	private List<Address> customerAddresses=new ArrayList<>(); //ref Address
	@NotNull
	@OneToMany(mappedBy="customer",cascade=CascadeType.ALL)
	//@Column(length=10)
	private List<Order> orders=new ArrayList<>();
	}
