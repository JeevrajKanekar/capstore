package com.capg.CapStore.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capg.CapStore.entity.Category;
import com.capg.CapStore.entity.Product;

@Repository
public class CapStoreRepositoryImpl implements ICapStoreRepository{
	@PersistenceContext
	EntityManager manager;

	@Override
	public void addData() 
	{
		
		
		//Category cat1=manager.find(Category.class, 1);
		Category cat1=new Category();
		cat1.setCategoryName("Men");
		cat1.setSub_category("T-shirt");
		manager.persist(cat1);
		System.out.println(cat1.getCategoryId());
		cat1.setCategoryId(cat1.getCategoryId());
		Product product1=new Product();
		product1.setProductName("Blue Jeans");
		product1.setDescription("Exclusive H&M Jeans");
		product1.setAverageRatings(3.0);
		product1.setImageUrl("D:/xyz.jpg");
		product1.setKeywordtoSearch("jeans");
		product1.setPrice(5000);
		product1.setCategory(cat1);
		System.out.println("Data inserted");
		Product product2=new Product();
		product2.setProductName("Black Jeans");
		product2.setDescription("Exclusive H&M Jeans");
		product2.setAverageRatings(3.0);
		product2.setImageUrl("D:/xyz.jpg");
		product2.setKeywordtoSearch("jeans");
		product2.setPrice(4000);
		product2.setCategory(cat1);
		manager.persist(product1);
		manager.persist(product2);
		//manager.flush();
		System.out.println("Data inserted");
		System.out.println(product1);
		System.out.println(product2);
	}

	
	

}
