package com.capg.CapStore.entity;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="Wishlist_tbl")
public class Wishlist {
	
	public Wishlist(int wishlistId, List<Product> products, @NotNull @Size(max = 6) Customer customer,
			@NotNull @Size(max = 30) String addedOn) {
		super();
		this.wishlistId = wishlistId;
		this.products = products;
		this.customer = customer;
		this.addedOn = addedOn;
	}
	@Override
	public String toString() {
		return "Wishlist [wishlistId=" + wishlistId + ", products=" + products + ", customer=" + customer + ", addedOn="
				+ addedOn + "]";
	}
	public int getWishlistId() {
		return wishlistId;
	}
	public void setWishlistId(int wishlistId) {
		this.wishlistId = wishlistId;
	}
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public String getAddedOn() {
		return addedOn;
	}
	public void setAddedOn(String addedOn) {
		this.addedOn = addedOn;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int wishlistId;
	@OneToMany(mappedBy="productId")
//?
	private List<Product> products;// foreign key of product,//liST
	@OneToOne
	@NotNull
	//@Column(length=6)
	//@Size(max=6)
	private Customer customer; // foreign key of customer,
	@NotNull
	@Column(length=30)
	//@Size(max=30)
	private String addedOn;
	public Wishlist() 
	{
		products=new ArrayList<>();
	}
}
