package com.capg.CapStore.service;

public interface ICapStoreService {

	public void addData();

}
