package com.capg.CapStore.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

@Entity
@Table(name="Discount_tbl")
public class Discount {

	public Discount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Discount(int discountId, @Size(max = 10) double productPrice, @Size(max = 6) Category category,
			@Size(max = 30) String startDate, @Size(max = 30) String expiryDate, @Max(100) @Min(0) int discountPercent) {
		super();
		this.discountId = discountId;
		this.productPrice = productPrice;
		this.category = category;
		this.startDate = startDate;
		this.expiryDate = expiryDate;
		this.discountPercent = discountPercent;
	}
	@Override
	public String toString() {
		return "Discount [discountId=" + discountId + ", productPrice=" + productPrice + ", category=" + category
				+ ", startDate=" + startDate + ", expiryDate=" + expiryDate + ", discountPercent=" + discountPercent
				+ "]";
	}
	public int getDiscountId() {
		return discountId;
	}
	public void setDiscountId(int discountId) {
		this.discountId = discountId;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public int getDiscountPercent() {
		return discountPercent;
	}
	public void setDiscountPercent(int discountPercent) {
		this.discountPercent = discountPercent;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int discountId;
	//@Size(max=10)
	@Column(length=10)
	private double productPrice;
	//@Size(max=6)
	//@Column(length=6)
	@OneToOne
	private Category category; 
	//@Size(max=30)
	@Column(length=30)
	private String startDate;
	//@Size(max=30)
	@Column(length=30)
	private String expiryDate;
	@Max(100)
	@Min(0)
	@Column(length=20)
	private int discountPercent;
}
