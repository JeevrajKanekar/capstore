package com.capg.CapStore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
@Entity
@Table(name="Inventory_tbl")
public class Inventory {
	public Inventory() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Inventory(int inventoryId, @NotNull Merchant merchant, @NotNull Product product, @NotNull int productInStock,
			@NotNull @Size(max = 30) String productCategory) {
		super();
		this.inventoryId = inventoryId;
		this.merchant = merchant;
		this.product = product;
		this.productInStock = productInStock;
		this.productCategory = productCategory;
	}
	@Override
	public String toString() {
		return "Inventory [inventoryId=" + inventoryId + ", merchant=" + merchant + ", product=" + product
				+ ", productInStock=" + productInStock + ", productCategory=" + productCategory + "]";
	}
	public int getInventoryId() {
		return inventoryId;
	}
	public void setInventoryId(int inventoryId) {
		this.inventoryId = inventoryId;
	}
	public Merchant getMerchant() {
		return merchant;
	}
	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public int getProductInStock() {
		return productInStock;
	}
	public void setProductInStock(int productInStock) {
		this.productInStock = productInStock;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int inventoryId;
	@OneToOne
	@NotNull
	//@Column(length=10)
	private Merchant merchant;//foreign key of merchant,
	
	@OneToOne
	@NotNull
	//@Column(length=10)
	private Product product;// foreign key of product,
	@NotNull
	@Column(length=10)
	private int productInStock; 
	@NotNull
	@Size(max=30)
	@Column(length=30)
	private String productCategory;// foreign key of category

}
