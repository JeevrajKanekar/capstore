package com.capg.CapStore.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="Invoice_tbl")
public class Invoice {

	public Invoice() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Invoice(int invoiceId, @NotNull Order order, @Size(max = 30) String invoiceDate) {
		super();
		this.invoiceId = invoiceId;
		this.order = order;
		this.invoiceDate = invoiceDate;
	}
	@Override
	public String toString() {
		return "Invoice [invoiceId=" + invoiceId + ", order=" + order + ", invoiceDate=" + invoiceDate + "]";
	}
	public int getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(int invoiceId) {
		this.invoiceId = invoiceId;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int invoiceId;
	@OneToOne
	@NotNull
	//@Column(length=6)
	private Order order;
	//@Size(max=30)
	@Column(length=30)
	private String invoiceDate;

}
