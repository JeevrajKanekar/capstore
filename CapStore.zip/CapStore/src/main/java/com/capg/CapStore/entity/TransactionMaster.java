package com.capg.CapStore.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="transaction_master_tbl")
public class TransactionMaster {
	public TransactionMaster() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TransactionMaster(int transactionId, @NotNull @Size(max = 20) String transactiontype,
			@NotNull @Size(max = 30) String transactiondate, @NotNull @Size(max = 6) Order order,
			@NotNull @Size(max = 30) String cardName, @NotNull @Size(max = 16) String cardNumber,
			@NotNull @Size(max = 3) String cardCvv, @NotNull @Size(max = 2) String cardExpMonth,
			@NotNull @Size(max = 4, min = 4) String cardExpYear, @NotNull @Size(max = 10) double amount) {
		super();
		this.transactionId = transactionId;
		this.transactiontype = transactiontype;
		this.transactiondate = transactiondate;
		this.order = order;
		this.cardName = cardName;
		this.cardNumber = cardNumber;
		this.cardCvv = cardCvv;
		this.cardExpMonth = cardExpMonth;
		this.cardExpYear = cardExpYear;
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "TransactionMaster [transactionId=" + transactionId + ", transactiontype=" + transactiontype
				+ ", transactiondate=" + transactiondate + ", order=" + order + ", cardName=" + cardName
				+ ", cardNumber=" + cardNumber + ", cardCvv=" + cardCvv + ", cardExpMonth=" + cardExpMonth
				+ ", cardExpYear=" + cardExpYear + ", amount=" + amount + "]";
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactiontype() {
		return transactiontype;
	}
	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}
	public String getTransactiondate() {
		return transactiondate;
	}
	public void setTransactiondate(String transactiondate) {
		this.transactiondate = transactiondate;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public String getCardName() {
		return cardName;
	}
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCardCvv() {
		return cardCvv;
	}
	public void setCardCvv(String cardCvv) {
		this.cardCvv = cardCvv;
	}
	public String getCardExpMonth() {
		return cardExpMonth;
	}
	public void setCardExpMonth(String cardExpMonth) {
		this.cardExpMonth = cardExpMonth;
	}
	public String getCardExpYear() {
		return cardExpYear;
	}
	public void setCardExpYear(String cardExpYear) {
		this.cardExpYear = cardExpYear;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int transactionId;
	@NotNull
	@Size(max=20)
	@Column(length=20)
	private String transactiontype;
	@NotNull
	//@Size(max=30)
	@Column(length=30)
	private String transactiondate;
	@OneToOne
	@NotNull
	//@Size(max=6)
	//@Column(length=6)
	private Order order; //references order
	@NotNull
	@Size(max=30)
	@Column(length=30)
	private String cardName;
	@NotNull
	@Size(max=16)
	@Column(length=16)
	private String cardNumber;
	@NotNull
	@Size(max=3)
	@Column(length=3)
	private String cardCvv;
	@NotNull
	@Size(max=2)
	@Column(length=2)
	private String cardExpMonth;
	@NotNull
	@Size(max=4,min=4)
	@Column(length=4)
	private String cardExpYear;
	@NotNull
	//@Size(max=10)
	@Column(length=10)
	private double amount;
}
