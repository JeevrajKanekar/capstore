package com.capg.CapStore.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="Address_tbl")
public class Address {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int addressId;
	@NotNull
	@Column(length=10)
	private int mobileNo;
	@NotNull
	@Column(length=6)
	private int addressPincode;
	@NotNull
	@Size(max=10)
	@Column(length=10)
	private String roomNo;
	@Size(max=50)
	@Column(length=50)
	private String area;
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Size(max=30)
	@Column(length=30)
	private String landmark;
	@NotNull
	@Size(max=20)
	@Column(length=20)
	private String city;
	@NotNull
	@Size(max=30)
	@Column(length=30)
	private String state;
	@NotNull
	@Size(max=50)
	@Column(length=50)
	private String addressType;
	@ManyToOne(cascade=CascadeType.PERSIST)
	private Customer customer;
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Address(int addressId, @NotNull @Size(max = 10, min = 10) int mobileNo,
			@NotNull @Size(max = 6, min = 6) int addressPincode, @NotNull @Size(max = 10) String roomNo,
			@Size(max = 50) String area, @Size(max = 30) String landmark, @NotNull @Size(max = 20) String city,
			@NotNull @Size(max = 30) String state, @NotNull @Size(max = 50) String addressType) {
		super();
		this.addressId = addressId;
		this.mobileNo = mobileNo;
		this.addressPincode = addressPincode;
		this.roomNo = roomNo;
		this.area = area;
		this.landmark = landmark;
		this.city = city;
		this.state = state;
		this.addressType = addressType;
	}
	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", mobileNo=" + mobileNo + ", addressPincode=" + addressPincode
				+ ", roomNo=" + roomNo + ", area=" + area + ", landmark=" + landmark + ", city=" + city + ", state="
				+ state + ", addressType=" + addressType + "]";
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getAddressPincode() {
		return addressPincode;
	}
	public void setAddressPincode(int addressPincode) {
		this.addressPincode = addressPincode;
	}
	public String getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getAddressType() {
		return addressType;
	}
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}
	
}
